package com.example.springboot_basic.domain.post;

public enum PostCategory {
    NOTICE, BOARD
}
