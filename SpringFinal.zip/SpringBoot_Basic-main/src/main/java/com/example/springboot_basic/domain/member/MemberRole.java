package com.example.springboot_basic.domain.member;

public enum MemberRole {
    ROLE_USER, ROLE_MANAGER, ROLE_ADMIN
}
