package com.example.springboot_basic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootBasicApplicationTests {

    @Test
    void contextLoads() {
    }

}
